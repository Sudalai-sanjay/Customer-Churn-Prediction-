"""
Tests for the churn prediction API.

Run:
    pytest tests/ -v
"""

import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_root():
    response = client.get("/")
    assert response.status_code == 200


def test_predict_valid_payload():
    payload = {
        "age": 32,
        "tenure": 14,
        "monthly_charges": 75.5,
        "contract_type": "Month-to-month",
        "support_tickets": 4,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert "churn_prediction" in body
    assert "churn_probability" in body
    assert body["churn_prediction"] in (0, 1)
    assert 0.0 <= body["churn_probability"] <= 1.0


def test_predict_high_risk_customer_scores_high():
    # Month-to-month, short tenure, many tickets & complaints -> expect high churn probability
    payload = {
        "age": 24,
        "tenure": 1,
        "monthly_charges": 95.0,
        "contract_type": "Month-to-month",
        "payment_method": "Electronic check",
        "support_tickets": 8,
        "num_services": 2,
        "previous_complaints": 4,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert response.json()["churn_probability"] > 0.5


def test_predict_low_risk_customer_scores_low():
    # Two-year contract, long tenure, no tickets/complaints -> expect low churn probability
    payload = {
        "age": 45,
        "tenure": 60,
        "monthly_charges": 40.0,
        "contract_type": "Two year",
        "payment_method": "Bank transfer",
        "support_tickets": 0,
        "num_services": 4,
        "previous_complaints": 0,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert response.json()["churn_probability"] < 0.5


def test_predict_missing_required_field_returns_422():
    payload = {
        "tenure": 14,
        "monthly_charges": 75.5,
        "contract_type": "Month-to-month",
        "support_tickets": 4,
    }  # missing "age"
    response = client.post("/predict", json=payload)
    assert response.status_code == 422


def test_predict_invalid_contract_type_returns_422():
    payload = {
        "age": 32,
        "tenure": 14,
        "monthly_charges": 75.5,
        "contract_type": "Lifetime",  # not a valid enum value
        "support_tickets": 4,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 422
