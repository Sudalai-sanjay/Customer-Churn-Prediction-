import os
import sys

import pandas as pd

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))
from preprocessing import clean_data, cap_outliers_iqr, get_feature_and_target


def test_cap_outliers_iqr_clips_extremes():
    df = pd.DataFrame({"x": [1, 2, 3, 4, 5, 1000]})
    capped = cap_outliers_iqr(df, ["x"])
    assert capped["x"].max() < 1000


def test_clean_data_removes_duplicates():
    df = pd.DataFrame({
        "Age": [30, 30],
        "Gender": ["Male", "Male"],
        "Tenure": [5, 5],
        "MonthlyCharges": [50.0, 50.0],
        "TotalCharges": [250.0, 250.0],
        "ContractType": ["One year", "One year"],
        "PaymentMethod": ["Credit card", "Credit card"],
        "NumSupportTickets": [1, 1],
        "NumServicesSubscribed": [2, 2],
        "PreviousComplaints": [0, 0],
        "Churn": [0, 0],
    })
    cleaned = clean_data(df)
    assert len(cleaned) == 1


def test_get_feature_and_target_splits_correctly():
    df = pd.DataFrame({
        "Age": [30], "Gender": ["Male"], "Tenure": [5], "MonthlyCharges": [50.0],
        "TotalCharges": [250.0], "ContractType": ["One year"], "PaymentMethod": ["Credit card"],
        "NumSupportTickets": [1], "NumServicesSubscribed": [2], "PreviousComplaints": [0],
        "Churn": [1],
    })
    X, y = get_feature_and_target(df)
    assert "Churn" not in X.columns
    assert y.iloc[0] == 1
