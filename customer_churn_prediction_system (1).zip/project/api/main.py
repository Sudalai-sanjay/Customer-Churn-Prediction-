"""
main.py
-------
FastAPI service exposing the trained churn model.

Run locally:
    uvicorn api.main:app --reload --port 8000

Then visit http://127.0.0.1:8000/docs for interactive Swagger UI.
"""

import os
from contextlib import asynccontextmanager

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from api.schemas import CustomerFeatures, ChurnPrediction

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "churn_model.joblib")


@asynccontextmanager
async def lifespan(app: FastAPI):
    get_model()  # load model once at startup
    yield


app = FastAPI(
    title="Customer Churn Prediction API",
    description="Predicts the probability that a customer will churn based on account features.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_model = None


def get_model():
    global _model
    if _model is None:
        if not os.path.exists(MODEL_PATH):
            raise RuntimeError(
                f"Model file not found at {MODEL_PATH}. Run `python src/train.py` first."
            )
        _model = joblib.load(MODEL_PATH)
    return _model


@app.get("/")
def root():
    return {"message": "Customer Churn Prediction API is running. See /docs for usage."}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict", response_model=ChurnPrediction)
def predict(customer: CustomerFeatures):
    model = get_model()

    total_charges = customer.total_charges
    if total_charges is None:
        # Simple fallback estimate when total_charges isn't provided by the caller
        total_charges = customer.monthly_charges * max(customer.tenure, 1)

    row = pd.DataFrame([{
        "Age": customer.age,
        "Gender": customer.gender,
        "Tenure": customer.tenure,
        "MonthlyCharges": customer.monthly_charges,
        "TotalCharges": total_charges,
        "ContractType": customer.contract_type,
        "PaymentMethod": customer.payment_method,
        "NumSupportTickets": customer.support_tickets,
        "NumServicesSubscribed": customer.num_services,
        "PreviousComplaints": customer.previous_complaints,
    }])

    try:
        proba = model.predict_proba(row)[0, 1]
        pred = int(proba >= 0.5)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {e}")

    return ChurnPrediction(churn_prediction=pred, churn_probability=round(float(proba), 4))
