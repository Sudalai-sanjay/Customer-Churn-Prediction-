"""Pydantic request/response schemas for the churn prediction API."""

from typing import Literal
from pydantic import BaseModel, Field


class CustomerFeatures(BaseModel):
    age: int = Field(..., ge=18, le=100, description="Customer age in years")
    gender: Literal["Male", "Female"] = Field(default="Male")
    tenure: int = Field(..., ge=0, le=100, description="Months as a customer")
    monthly_charges: float = Field(..., ge=0, description="Current monthly bill amount")
    total_charges: float = Field(default=None, ge=0, description="Lifetime billed amount (optional; estimated if omitted)")
    contract_type: Literal["Month-to-month", "One year", "Two year"]
    payment_method: Literal["Electronic check", "Mailed check", "Bank transfer", "Credit card"] = Field(
        default="Electronic check"
    )
    support_tickets: int = Field(..., ge=0, le=50, description="Number of support tickets raised")
    num_services: int = Field(default=1, ge=0, le=20, description="Number of services subscribed")
    previous_complaints: int = Field(default=0, ge=0, le=20)

    model_config = {
        "json_schema_extra": {
            "example": {
                "age": 32,
                "gender": "Male",
                "tenure": 14,
                "monthly_charges": 75.5,
                "contract_type": "Month-to-month",
                "payment_method": "Electronic check",
                "support_tickets": 4,
                "num_services": 3,
                "previous_complaints": 1,
            }
        }
    }


class ChurnPrediction(BaseModel):
    churn_prediction: int
    churn_probability: float
