"""
preprocessing.py
-----------------
Data loading and preprocessing utilities for the Customer Churn Prediction system.

Design decisions (see README for full rationale):
- Missing numeric values -> median imputation (robust to outliers/skew).
- Missing categorical values -> mode ("most_frequent") imputation.
- Outliers -> capped using the IQR method rather than dropped, to avoid losing
  potentially informative customers (e.g. very high spenders).
- Categorical variables -> One-Hot Encoding (no ordinal relationship between
  categories such as ContractType or PaymentMethod).
- Numerical variables -> StandardScaler, mainly to benefit Logistic Regression;
  tree-based models are scale-invariant but scaling does not hurt them.
"""

from __future__ import annotations

import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

# Columns that should not be used as model features
ID_COLUMNS = ["CustomerID"]
TARGET_COLUMN = "Churn"

NUMERIC_FEATURES = [
    "Age",
    "Tenure",
    "MonthlyCharges",
    "TotalCharges",
    "NumSupportTickets",
    "NumServicesSubscribed",
    "PreviousComplaints",
]

CATEGORICAL_FEATURES = [
    "Gender",
    "ContractType",
    "PaymentMethod",
]


def load_data(path: str) -> pd.DataFrame:
    """Load the raw churn dataset from CSV."""
    df = pd.read_csv(path)
    return df


def cap_outliers_iqr(df: pd.DataFrame, columns: list[str], factor: float = 1.5) -> pd.DataFrame:
    """Cap outliers in the given numeric columns using the IQR rule.

    Values below Q1 - factor*IQR or above Q3 + factor*IQR are clipped to
    those bounds rather than removed, preserving row count.
    """
    df = df.copy()
    for col in columns:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - factor * iqr
        upper = q3 + factor * iqr
        df[col] = df[col].clip(lower=lower, upper=upper)
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop exact duplicates, fix dtypes, cap extreme outliers."""
    df = df.copy()
    df = df.drop_duplicates()

    # Ensure numeric columns are numeric (coerce bad values to NaN, handled by imputer)
    for col in NUMERIC_FEATURES:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Cap outliers on skew-prone columns only (Age, MonthlyCharges are the ones
    # the synthetic generator seeded with extreme values; TotalCharges follows).
    df = cap_outliers_iqr(df, ["Age", "MonthlyCharges", "TotalCharges"])

    return df


def build_preprocessor() -> ColumnTransformer:
    """Build the sklearn ColumnTransformer used inside the modeling Pipeline."""
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_pipeline, NUMERIC_FEATURES),
        ("cat", categorical_pipeline, CATEGORICAL_FEATURES),
    ])
    return preprocessor


def get_feature_and_target(df: pd.DataFrame):
    """Split a cleaned dataframe into X (features) and y (target)."""
    feature_cols = NUMERIC_FEATURES + CATEGORICAL_FEATURES
    X = df[feature_cols].copy()
    y = df[TARGET_COLUMN].copy()
    return X, y


def prepare_dataset(path: str):
    """Convenience wrapper: load -> clean -> split into X, y."""
    df = load_data(path)
    df = clean_data(df)
    X, y = get_feature_and_target(df)
    return X, y
