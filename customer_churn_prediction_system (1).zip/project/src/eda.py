"""
eda.py
------
Exploratory Data Analysis for the churn dataset. Generates PNG charts into
reports/figures/ covering the required analyses:
  - Churn distribution
  - Churn by contract type
  - Churn by tenure
  - Churn by monthly charges
  - Two additional insights: churn by support tickets, correlation heatmap

Run:
    python src/eda.py
"""

import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

sys.path.append(os.path.dirname(__file__))
from preprocessing import load_data, clean_data

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "customer_churn_dataset.csv")
FIG_DIR = os.path.join(os.path.dirname(__file__), "..", "reports", "figures")

sns.set_theme(style="whitegrid")


def savefig(name):
    path = os.path.join(FIG_DIR, name)
    plt.tight_layout()
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"Saved {path}")


def main():
    os.makedirs(FIG_DIR, exist_ok=True)
    df = load_data(DATA_PATH)
    df = clean_data(df)

    # 1. Churn distribution
    plt.figure(figsize=(5, 4))
    sns.countplot(data=df, x="Churn", hue="Churn", palette="Set2", legend=False)
    plt.title("Churn Distribution")
    plt.xlabel("Churn (0 = Retained, 1 = Churned)")
    savefig("01_churn_distribution.png")

    # 2. Churn by contract type
    plt.figure(figsize=(6, 4))
    sns.countplot(data=df, x="ContractType", hue="Churn", palette="Set2")
    plt.title("Churn by Contract Type")
    savefig("02_churn_by_contract_type.png")

    # 3. Churn by tenure
    plt.figure(figsize=(6, 4))
    sns.histplot(data=df, x="Tenure", hue="Churn", multiple="stack", bins=20, palette="Set2")
    plt.title("Churn by Tenure (months)")
    savefig("03_churn_by_tenure.png")

    # 4. Churn by monthly charges
    plt.figure(figsize=(6, 4))
    sns.boxplot(data=df, x="Churn", y="MonthlyCharges", hue="Churn", palette="Set2", legend=False)
    plt.title("Monthly Charges by Churn")
    savefig("04_churn_by_monthly_charges.png")

    # 5. Additional insight: churn by number of support tickets
    plt.figure(figsize=(6, 4))
    sns.barplot(data=df, x="NumSupportTickets", y="Churn", hue="NumSupportTickets",
                estimator="mean", palette="Set2", legend=False)
    plt.title("Churn Rate by Number of Support Tickets")
    plt.ylabel("Churn Rate")
    savefig("05_churn_by_support_tickets.png")

    # 6. Additional insight: correlation heatmap of numeric features
    numeric_cols = ["Age", "Tenure", "MonthlyCharges", "TotalCharges",
                     "NumSupportTickets", "NumServicesSubscribed", "PreviousComplaints", "Churn"]
    plt.figure(figsize=(7, 6))
    corr = df[numeric_cols].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Heatmap")
    savefig("06_correlation_heatmap.png")

    print("\nEDA complete. Figures saved to reports/figures/")


if __name__ == "__main__":
    main()
