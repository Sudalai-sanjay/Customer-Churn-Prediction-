"""
train.py
--------
Trains and compares multiple ML models for customer churn prediction,
evaluates them, selects the best one, and persists it (with its
preprocessing pipeline) to disk for the API to consume.

Run:
    python src/train.py
"""

from __future__ import annotations

import json
import os
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

sys.path.append(os.path.dirname(__file__))
from preprocessing import load_data, clean_data, get_feature_and_target, build_preprocessor

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "customer_churn_dataset.csv")
MODELS_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
REPORTS_DIR = os.path.join(os.path.dirname(__file__), "..", "reports")

RANDOM_STATE = 42


def get_candidate_models() -> dict:
    models = {
        "LogisticRegression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE),
        "DecisionTree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=RANDOM_STATE),
        "RandomForest": RandomForestClassifier(
            n_estimators=300, max_depth=10, class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
        ),
    }
    if XGBOOST_AVAILABLE:
        models["XGBoost"] = XGBClassifier(
            n_estimators=300,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=RANDOM_STATE,
        )
    return models


def evaluate_model(model, X_test, y_test) -> dict:
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    }
    return metrics


def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)

    print(f"Loading data from {DATA_PATH} ...")
    df = load_data(DATA_PATH)
    df = clean_data(df)
    X, y = get_feature_and_target(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    results = {}
    fitted_pipelines = {}

    for name, model in get_candidate_models().items():
        print(f"\nTraining {name} ...")
        pipeline = Pipeline(steps=[
            ("preprocessor", build_preprocessor()),
            ("classifier", model),
        ])
        pipeline.fit(X_train, y_train)

        metrics = evaluate_model(pipeline, X_test, y_test)
        results[name] = metrics
        fitted_pipelines[name] = pipeline

        print(f"  Accuracy : {metrics['accuracy']:.4f}")
        print(f"  Precision: {metrics['precision']:.4f}")
        print(f"  Recall   : {metrics['recall']:.4f}")
        print(f"  F1-score : {metrics['f1_score']:.4f}")
        print(f"  ROC-AUC  : {metrics['roc_auc']:.4f}")

    # --- Model selection ---
    # Business context: missing an actual churner (false negative) is costlier
    # than a false-positive retention offer, so we prioritize ROC-AUC (overall
    # ranking quality) with F1 as a tiebreaker rather than raw accuracy, since
    # the classes are imbalanced (~33% churn).
    best_name = max(results, key=lambda n: (results[n]["roc_auc"], results[n]["f1_score"]))
    best_pipeline = fitted_pipelines[best_name]
    best_metrics = results[best_name]

    print(f"\n=== Selected model: {best_name} ===")
    print(json.dumps(best_metrics, indent=2))

    # Persist the winning pipeline (preprocessing + model together)
    model_path = os.path.join(MODELS_DIR, "churn_model.joblib")
    joblib.dump(best_pipeline, model_path)
    print(f"\nSaved best model pipeline to {model_path}")

    # Save comparison report
    report = {
        "results": results,
        "selected_model": best_name,
        "selection_reason": (
            "Selected by highest ROC-AUC (ranking quality under class imbalance), "
            "with F1-score as a tiebreaker. Business priority is catching likely "
            "churners (recall) while keeping precision reasonable so retention "
            "offers aren't wasted on customers who wouldn't have churned anyway."
        ),
    }
    report_path = os.path.join(REPORTS_DIR, "model_comparison.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"Saved comparison report to {report_path}")


if __name__ == "__main__":
    main()
