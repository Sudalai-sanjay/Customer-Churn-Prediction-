"""
streamlit_app.py
-----------------
A simple web UI for the churn model: fill in customer details, click Predict,
see the churn prediction and probability instantly.

Run locally:
    streamlit run streamlit_app.py

Deploy for a free public link: push this file (and models/churn_model.joblib)
to your GitHub repo, then deploy on https://share.streamlit.io (Streamlit
Community Cloud) pointing at this file. See README section "Live Demo Link"
for the exact steps.
"""

import os

import joblib
import pandas as pd
import streamlit as st

MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "churn_model.joblib")

st.set_page_config(page_title="Customer Churn Predictor", page_icon="📉", layout="centered")


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


st.title("📉 Customer Churn Predictor")
st.write("Enter a customer's details below to predict whether they're likely to churn.")

model = load_model()

with st.form("churn_form"):
    col1, col2 = st.columns(2)

    with col1:
        age = st.number_input("Age", min_value=18, max_value=100, value=32)
        gender = st.selectbox("Gender", ["Male", "Female"])
        tenure = st.number_input("Tenure (months)", min_value=0, max_value=100, value=14)
        monthly_charges = st.number_input("Monthly Charges ($)", min_value=0.0, value=75.5, step=0.5)
        total_charges = st.number_input(
            "Total Charges ($) — leave 0 to auto-estimate", min_value=0.0, value=0.0, step=1.0
        )

    with col2:
        contract_type = st.selectbox("Contract Type", ["Month-to-month", "One year", "Two year"])
        payment_method = st.selectbox(
            "Payment Method", ["Electronic check", "Mailed check", "Bank transfer", "Credit card"]
        )
        support_tickets = st.number_input("Number of Support Tickets", min_value=0, max_value=50, value=4)
        num_services = st.number_input("Number of Services Subscribed", min_value=0, max_value=20, value=3)
        previous_complaints = st.number_input("Previous Complaints", min_value=0, max_value=20, value=1)

    submitted = st.form_submit_button("Predict Churn", use_container_width=True)

if submitted:
    tc = total_charges if total_charges > 0 else monthly_charges * max(tenure, 1)

    row = pd.DataFrame([{
        "Age": age,
        "Gender": gender,
        "Tenure": tenure,
        "MonthlyCharges": monthly_charges,
        "TotalCharges": tc,
        "ContractType": contract_type,
        "PaymentMethod": payment_method,
        "NumSupportTickets": support_tickets,
        "NumServicesSubscribed": num_services,
        "PreviousComplaints": previous_complaints,
    }])

    proba = model.predict_proba(row)[0, 1]
    pred = int(proba >= 0.5)

    st.divider()
    if pred == 1:
        st.error(f"⚠️ Likely to CHURN — probability: {proba:.2%}")
    else:
        st.success(f"✅ Likely to STAY — churn probability: {proba:.2%}")

    st.progress(min(max(proba, 0.0), 1.0))
    st.caption(f"Raw output: churn_prediction={pred}, churn_probability={round(float(proba), 4)}")
